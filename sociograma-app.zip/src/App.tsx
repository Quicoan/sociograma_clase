import React, { useState } from "react";
import { complete, getApiKey, setApiKey, localGroups, localSim, DEFAULT_QUESTIONS } from "./ai";

const MAX_SELECTIONS = 3;
type Answers = Record<string, string[]>;

interface Question {
  id: string;
  text: string;
  profile: string;
}

interface GroupSuggestion {
  groups: string[][];
  rationale: string;
  groupNotes?: string[];
}

interface SimResult {
  conflicts: { issue: string; severity: "alta" | "media" | "baja"; suggestion: string }[];
  roles: { member: string; role: string; reason: string }[];
  performance: { task: string; score: number; notes: string }[];
  overall: string;
}

// ── Setup ──────────────────────────────────────────────────────────────────
function Setup({ onStart }: { onStart: (students: string[], groupSize: number) => void }) {
  const [count, setCount] = useState(30);
  const [prefix, setPrefix] = useState("Alumno");
  const [customNames, setCustomNames] = useState("");
  const [useCustom, setUseCustom] = useState(false);
  const [groupSize, setGroupSize] = useState(5);
  const [apiKey, setKey] = useState(getApiKey());
  const customList = Array.from(new Set(customNames.split("\n").map((n) => n.trim()).filter(Boolean)));
  const valid = !useCustom || customList.length > 0;

  const handleStart = () => {
    let students: string[];
    setApiKey(apiKey.trim());
    if (useCustom) {
      students = customList;
    } else {
      students = Array.from({ length: count }, (_, i) => `${prefix} ${i + 1}`);
    }
    onStart(students, groupSize);
  };

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
        <label className="flex items-center gap-3 cursor-pointer">
          <input type="checkbox" checked={useCustom} onChange={(e) => setUseCustom(e.target.checked)} className="w-4 h-4" />
          <span className="text-gray-700 font-medium">Introducir nombres reales</span>
        </label>
      </div>

      {useCustom ? (
        <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
          <label className="block text-sm font-medium text-gray-700 mb-2">Un nombre por línea:</label>
          <textarea
            value={customNames}
            onChange={(e) => setCustomNames(e.target.value)}
            rows={8}
            placeholder={"Ana García\nCarlos López\nMaría Martínez\n..."}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
      ) : (
        <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Número de alumnos: <span className="text-blue-600 font-bold">{count}</span>
            </label>
            <input type="range" min={5} max={40} value={count} onChange={(e) => setCount(Number(e.target.value))} className="w-full" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Prefijo de nombre:</label>
            <input
              type="text"
              value={prefix}
              onChange={(e) => setPrefix(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Alumnos por grupo: <span className="text-blue-600 font-bold">{groupSize}</span>
        </label>
        <input type="range" min={2} max={8} value={groupSize} onChange={(e) => setGroupSize(Number(e.target.value))} className="w-full" />
      </div>

      <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
        <label className="block text-sm font-medium text-gray-700 mb-1">Clave de API de Anthropic (opcional)</label>
        <input type="password" value={apiKey} onChange={(e) => setKey(e.target.value)} placeholder="sk-ant-..." className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none" />
        <p className="text-xs text-gray-500 mt-1">Sin clave, la app usa preguntas y algoritmos locales. La clave se guarda solo en tu navegador.</p>
      </div>

      {!valid && <p className="text-sm text-red-600">Introduce al menos un nombre válido.</p>}
      <button onClick={handleStart} disabled={!valid} className="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition disabled:opacity-50">
        Generar preguntas con IA →
      </button>
    </div>
  );
}

// ── Survey ─────────────────────────────────────────────────────────────────
function StudentForm({
  students,
  currentStudent,
  questions,
  onSubmit,
}: {
  students: string[];
  currentStudent: string;
  questions: Question[];
  onSubmit: (answers: Answers) => void;
}) {
  const [answers, setAnswers] = useState<Answers>({});

  const toggle = (qid: string, name: string) => {
    setAnswers((prev) => {
      const current = prev[qid] || [];
      if (current.includes(name)) return { ...prev, [qid]: current.filter((n) => n !== name) };
      if (current.length >= MAX_SELECTIONS) return prev;
      return { ...prev, [qid]: [...current, name] };
    });
  };

  const peers = students.filter((s) => s !== currentStudent);

  return (
    <div className="space-y-5">
      <p className="text-sm text-gray-500 italic">
        Selecciona hasta {MAX_SELECTIONS} compañeros por pregunta. Puedes saltarte cualquier pregunta.
      </p>
      {questions.map((q) => (
        <div key={q.id} className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
          <div className="flex items-start justify-between gap-2 mb-3">
            <p className="font-medium text-gray-800">{q.text}</p>
            <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-600 rounded-full whitespace-nowrap">{q.profile}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {peers.map((peer) => {
              const selected = (answers[q.id] || []).includes(peer);
              return (
                <button
                  key={peer}
                  onClick={() => toggle(q.id, peer)}
                  className={`px-3 py-1 rounded-full text-sm border transition ${
                    selected ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-700 border-gray-300 hover:border-blue-400"
                  }`}
                >
                  {peer}
                </button>
              );
            })}
          </div>
          <p className="text-xs text-gray-400 mt-2">{(answers[q.id] || []).length}/{MAX_SELECTIONS} — puedes dejar en blanco</p>
        </div>
      ))}
      <button onClick={() => onSubmit(answers)} className="w-full py-3 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition">
        Enviar respuestas
      </button>
    </div>
  );
}

// ── Charts ─────────────────────────────────────────────────────────────────
const PROFILE_COLORS: Record<string, string> = {
  Líder: "bg-purple-100 text-purple-800",
  Creativo: "bg-yellow-100 text-yellow-800",
  Mediador: "bg-green-100 text-green-800",
  Trabajador: "bg-blue-100 text-blue-800",
  Apoyo: "bg-pink-100 text-pink-800",
  Organizador: "bg-orange-100 text-orange-800",
};

const PROFILE_BAR_COLORS: Record<string, string> = {
  Líder: "#a855f7",
  Creativo: "#eab308",
  Mediador: "#22c55e",
  Trabajador: "#3b82f6",
  Apoyo: "#ec4899",
  Organizador: "#f97316",
  "Sin perfil": "#9ca3af",
};

function BarChart({ data }: { data: { label: string; value: number; color: string }[] }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <div className="space-y-2">
      {data.map((d) => (
        <div key={d.label} className="flex items-center gap-2">
          <span className="text-xs text-gray-600 w-24 shrink-0 text-right">{d.label}</span>
          <div className="flex-1 bg-gray-100 rounded-full h-5 overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{ width: `${(d.value / max) * 100}%`, backgroundColor: d.color }}
            />
          </div>
          <span className="text-xs font-bold text-gray-700 w-5 text-right">{d.value}</span>
        </div>
      ))}
    </div>
  );
}

function RadarChart({ scores, profiles }: { scores: Record<string, number>; profiles: string[] }) {
  const size = 160;
  const cx = size / 2;
  const cy = size / 2;
  const r = 60;
  const n = profiles.length;
  const max = Math.max(...profiles.map((p) => scores[p] || 0), 1);
  const angleOf = (i: number) => (Math.PI * 2 * i) / n - Math.PI / 2;
  const point = (i: number, val: number) => {
    const ratio = val / max;
    return { x: cx + r * ratio * Math.cos(angleOf(i)), y: cy + r * ratio * Math.sin(angleOf(i)) };
  };
  const outerPoint = (i: number) => ({ x: cx + r * Math.cos(angleOf(i)), y: cy + r * Math.sin(angleOf(i)) });
  const polygonPoints = profiles.map((p, i) => { const pt = point(i, scores[p] || 0); return `${pt.x},${pt.y}`; }).join(" ");
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      {[0.25, 0.5, 0.75, 1].map((ratio) => (
        <polygon key={ratio} points={profiles.map((_, i) => { const pt = { x: cx + r * ratio * Math.cos(angleOf(i)), y: cy + r * ratio * Math.sin(angleOf(i)) }; return `${pt.x},${pt.y}`; }).join(" ")} fill="none" stroke="#e5e7eb" strokeWidth="1" />
      ))}
      {profiles.map((_, i) => { const pt = outerPoint(i); return <line key={i} x1={cx} y1={cy} x2={pt.x} y2={pt.y} stroke="#e5e7eb" strokeWidth="1" />; })}
      <polygon points={polygonPoints} fill="#3b82f620" stroke="#3b82f6" strokeWidth="2" />
      {profiles.map((p, i) => {
        const lx = cx + (r + 18) * Math.cos(angleOf(i));
        const ly = cy + (r + 18) * Math.sin(angleOf(i));
        return <text key={p} x={lx} y={ly} textAnchor="middle" dominantBaseline="middle" fontSize="8" fill="#6b7280">{p}</text>;
      })}
    </svg>
  );
}

// ── Group Simulator ────────────────────────────────────────────────────────
const SEVERITY_COLORS: Record<string, string> = {
  alta: "bg-red-100 text-red-700 border-red-200",
  media: "bg-yellow-100 text-yellow-700 border-yellow-200",
  baja: "bg-green-100 text-green-700 border-green-200",
};

const TASK_ICONS: Record<string, string> = {
  "Presentación oral": "🎤",
  "Proyecto creativo": "🎨",
  "Investigación": "🔬",
  "Debate": "💬",
  "Tarea técnica": "⚙️",
};

function GroupSimulator({
  group,
  groupIndex,
  profiles,
}: {
  group: string[];
  groupIndex: number;
  profiles: Record<string, string>;
}) {
  const [result, setResult] = useState<SimResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<"conflicts" | "roles" | "performance">("conflicts");
  const [open, setOpen] = useState(false);

  const simulate = async () => {
    setLoading(true);
    setOpen(true);
    const members = group.map((m) => `${m} (${profiles[m] || "Sin perfil"})`).join(", ");
    const res = await complete([
      {
        role: "user",
        content: [
          {
            text: `Eres un psicólogo educativo experto en dinámica de grupos. Analiza este grupo:\n\nGRUPO ${groupIndex + 1}: ${members}\n\nSimula tres dimensiones:\n1. CONFLICTOS POTENCIALES: identifica 2-3 tensiones que pueden surgir, su severidad (alta/media/baja) y cómo gestionarlas.\n2. REPARTO DE ROLES: asigna un rol concreto a cada miembro para trabajar en equipo, con justificación breve.\n3. RENDIMIENTO POR TIPO DE TAREA: puntúa del 1-10 el rendimiento esperado en: Presentación oral, Proyecto creativo, Investigación, Debate, Tarea técnica. Añade una nota breve.\n\nResponde SOLO con JSON válido:\n{\n  "conflicts": [{"issue": "...", "severity": "alta|media|baja", "suggestion": "..."}],\n  "roles": [{"member": "nombre", "role": "rol", "reason": "..."}],\n  "performance": [{"task": "Presentación oral", "score": 7, "notes": "..."}, {"task": "Proyecto creativo", "score": 8, "notes": "..."}, {"task": "Investigación", "score": 6, "notes": "..."}, {"task": "Debate", "score": 7, "notes": "..."}, {"task": "Tarea técnica", "score": 5, "notes": "..."}],\n  "overall": "Valoración general en 2 frases"\n}`,
          },
        ],
      },
    ]);
    try {
      const match = res.response.match(/\{[\s\S]*\}/);
      const parsed = match ? JSON.parse(match[0]) : JSON.parse(res.response.trim());
      if (!Array.isArray(parsed.conflicts) || !Array.isArray(parsed.roles) || !Array.isArray(parsed.performance)) throw new Error("bad");
      setResult(parsed);
    } catch {
      setResult(localSim(group, profiles));
    }
    setLoading(false);
  };

  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <div className="bg-gray-50 px-4 py-3 flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-bold text-gray-500">GRUPO {groupIndex + 1}</p>
          <p className="text-sm text-gray-700 truncate">{group.join(", ")}</p>
        </div>
        <button
          onClick={result ? () => setOpen(!open) : simulate}
          disabled={loading}
          className="ml-3 px-3 py-1.5 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition disabled:opacity-50 shrink-0"
        >
          {loading ? "Simulando..." : result ? (open ? "▲ Cerrar" : "▼ Ver") : "▶ Simular"}
        </button>
        {result && !loading && (
          <button onClick={simulate} disabled={loading} className="ml-1 px-2 py-1.5 bg-gray-200 text-gray-600 text-xs rounded-lg hover:bg-gray-300 transition shrink-0">🔄</button>
        )}
      </div>

      {loading && (
        <div className="flex items-center justify-center py-8 gap-3">
          <div className="w-5 h-5 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
          <span className="text-sm text-gray-500">Analizando dinámica grupal...</span>
        </div>
      )}

      {result && open && !loading && (
        <div className="p-4 space-y-4">
          <p className="text-sm text-gray-600 italic border-l-4 border-indigo-300 pl-3">{result.overall}</p>
          <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
            {(["conflicts", "roles", "performance"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition ${
                  activeTab === tab ? "bg-white text-indigo-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
                }`}
              >
                {tab === "conflicts" ? "⚡ Conflictos" : tab === "roles" ? "🎭 Roles" : "📈 Rendimiento"}
              </button>
            ))}
          </div>

          {activeTab === "conflicts" && (
            <div className="space-y-3">
              {result.conflicts.map((c, i) => (
                <div key={i} className={`rounded-lg border p-3 ${SEVERITY_COLORS[c.severity]}`}>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-bold uppercase">{c.severity}</span>
                    <span className="text-xs font-semibold">{c.issue}</span>
                  </div>
                  <p className="text-xs opacity-80">💡 {c.suggestion}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === "roles" && (
            <div className="space-y-2">
              {result.roles.map((r, i) => (
                <div key={i} className="flex items-start gap-3 bg-gray-50 rounded-lg p-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-gray-800">{r.member}</span>
                      <span className="text-xs px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded-full">{r.role}</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{r.reason}</p>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "performance" && (
            <div className="space-y-3">
              {result.performance.map((p) => (
                <div key={p.task}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-gray-700">{TASK_ICONS[p.task] || "📋"} {p.task}</span>
                    <span className="text-xs font-bold text-indigo-600">{p.score}/10</span>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-2 mb-1">
                    <div className="h-2 rounded-full transition-all duration-500" style={{ width: `${p.score * 10}%`, backgroundColor: p.score >= 7 ? "#22c55e" : p.score >= 5 ? "#eab308" : "#ef4444" }} />
                  </div>
                  <p className="text-xs text-gray-400">{p.notes}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Results ────────────────────────────────────────────────────────────────
function Results({
  students,
  allAnswers,
  questions,
  groupSize,
  onReset,
}: {
  students: string[];
  allAnswers: Record<string, Answers>;
  questions: Question[];
  groupSize: number;
  onReset: () => void;
}) {
  const [groups, setGroups] = useState<GroupSuggestion | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeSection, setActiveSection] = useState<"profiles" | "groups" | "simulator">("profiles");

  const profileScores: Record<string, Record<string, number>> = {};
  students.forEach((s) => { profileScores[s] = {}; });
  students.forEach((chooser) => {
    const ans = allAnswers[chooser] || {};
    questions.forEach((q) => {
      (ans[q.id] || []).forEach((chosen) => {
        if (!profileScores[chosen][q.profile]) profileScores[chosen][q.profile] = 0;
        profileScores[chosen][q.profile]++;
      });
    });
  });

  const dominantProfile = (student: string) => {
    const scores = profileScores[student];
    if (!scores || Object.keys(scores).length === 0) return "Sin perfil";
    return Object.entries(scores).sort((a, b) => b[1] - a[1])[0][0];
  };

  const generateGroups = async () => {
    setLoading(true);
    const positiveQids = questions.map((q) => q.id);
    const mutualPairs: string[] = [];
    students.forEach((a) => {
      students.forEach((b) => {
        if (a >= b) return;
        const aChoosesB = positiveQids.some((qid) => (allAnswers[a]?.[qid] || []).includes(b));
        const bChoosesA = positiveQids.some((qid) => (allAnswers[b]?.[qid] || []).includes(a));
        if (aChoosesB && bChoosesA) mutualPairs.push(`${a} ↔ ${b}`);
      });
    });
    const rejectionPairs: string[] = [];
    students.forEach((a) => {
      students.forEach((b) => {
        if (a === b) return;
        const negQids = questions.filter((q) => q.profile === "Rechazo").map((q) => q.id);
        const aRejectsB = negQids.some((qid) => (allAnswers[a]?.[qid] || []).includes(b));
        if (aRejectsB) rejectionPairs.push(`${a} rechaza a ${b}`);
      });
    });
    const profileSummary = students.map((s) => ({ name: s, profile: dominantProfile(s), scores: profileScores[s] }));
    const res = await complete([
      {
        role: "user",
        content: [
          {
            text: `Eres un psicólogo educativo experto en dinámica de grupos. Tienes datos de un sociograma de una clase de ${students.length} alumnos.\n\nPERFILES DETECTADOS:\n${profileSummary.map((p) => `- ${p.name}: perfil dominante = ${p.profile}, puntuaciones = ${JSON.stringify(p.scores)}`).join("\n")}\n\nELECCIONES MUTUAS:\n${mutualPairs.length > 0 ? mutualPairs.join(", ") : "Ninguna detectada"}\n\nRECHAZOS DETECTADOS:\n${rejectionPairs.length > 0 ? rejectionPairs.join(", ") : "Ninguno detectado"}\n\nCRITERIOS para grupos ESTABLES de ~${groupSize} alumnos:\n1. Incluir al menos una elección mutua por grupo si es posible\n2. Mezclar perfiles complementarios\n3. NUNCA juntar alumnos con rechazo mutuo\n4. Distribuir alumnos aislados junto a perfiles Apoyo o Mediador\n5. Máximo 1-2 Líderes por grupo\n\nResponde SOLO con JSON válido:\n{\n  "groups": [["Alumno1","Alumno2",...], ...],\n  "rationale": "Explicación de la lógica",\n  "groupNotes": ["Nota grupo 1", "Nota grupo 2", ...]\n}`,
          },
        ],
      },
    ]);
    try {
      const match = res.response.match(/\{[\s\S]*\}/);
      const parsed = match ? JSON.parse(match[0]) : JSON.parse(res.response.trim());
      if (!Array.isArray(parsed.groups)) throw new Error("bad");
      setGroups(parsed);
    } catch {
      setGroups(localGroups(students, dominantProfiles, groupSize));
    }
    setActiveSection("groups");
    setLoading(false);
  };

  const allProfiles = ["Líder", "Creativo", "Mediador", "Trabajador", "Apoyo", "Organizador"];
  const profileCounts: Record<string, number> = {};
  students.forEach((s) => {
    const p = dominantProfile(s);
    profileCounts[p] = (profileCounts[p] || 0) + 1;
  });
  const dominantProfiles: Record<string, string> = {};
  students.forEach((s) => { dominantProfiles[s] = dominantProfile(s); });

  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      {/* Section tabs */}
      <div className="flex gap-1 bg-gray-100 rounded-xl p-1">
        {(["profiles", "groups", "simulator"] as const).map((sec) => (
          <button
            key={sec}
            onClick={() => setActiveSection(sec)}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition ${
              activeSection === sec ? "bg-white text-blue-700 shadow-sm" : "text-gray-500 hover:text-gray-700"
            }`}
          >
            {sec === "profiles" ? "📊 Perfiles" : sec === "groups" ? "🧩 Grupos" : "🔬 Simulador"}
          </button>
        ))}
      </div>

      {/* PROFILES SECTION */}
      {activeSection === "profiles" && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
            <h2 className="font-bold text-lg text-gray-800 mb-4">📊 Distribución de perfiles</h2>
            <BarChart
              data={Object.entries(profileCounts).sort((a, b) => b[1] - a[1]).map(([label, value]) => ({
                label, value, color: PROFILE_BAR_COLORS[label] || "#9ca3af",
              }))}
            />
            <div className="flex flex-wrap gap-2 mt-4">
              {Object.entries(profileCounts).map(([profile, count]) => (
                <span key={profile} className={`px-3 py-1 rounded-full text-sm font-medium ${PROFILE_COLORS[profile] || "bg-gray-100 text-gray-700"}`}>
                  {profile}: {count}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
            <h2 className="font-bold text-lg text-gray-800 mb-3">👤 Perfil por alumno</h2>
            <p className="text-xs text-gray-400 mb-3">Toca un alumno para ver su radar</p>
            <div className="space-y-1 max-h-64 overflow-y-auto">
              {students.map((s) => (
                <button
                  key={s}
                  onClick={() => setSelectedStudent(selectedStudent === s ? null : s)}
                  className={`w-full flex items-center justify-between text-sm px-2 py-1.5 rounded-lg transition ${
                    selectedStudent === s ? "bg-blue-50 border border-blue-200" : "hover:bg-gray-50"
                  }`}
                >
                  <span className="text-gray-700">{s}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${PROFILE_COLORS[dominantProfile(s)] || "bg-gray-100 text-gray-600"}`}>
                    {dominantProfile(s)}
                  </span>
                </button>
              ))}
            </div>
            {selectedStudent && (
              <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col items-center gap-2">
                <p className="font-semibold text-gray-800">{selectedStudent}</p>
                <RadarChart scores={profileScores[selectedStudent] || {}} profiles={allProfiles} />
                <div className="flex flex-wrap justify-center gap-2">
                  {allProfiles.map((p) => (
                    <span key={p} className="text-xs text-gray-500">{p}: <strong>{profileScores[selectedStudent]?.[p] || 0}</strong></span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {!groups ? (
            <button onClick={generateGroups} disabled={loading} className="w-full py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition disabled:opacity-50">
              {loading ? "Generando grupos con IA..." : "✨ Generar grupos complementarios"}
            </button>
          ) : (
            <div className="flex gap-2">
              <button onClick={() => setActiveSection("groups")} className="flex-1 py-3 bg-purple-100 text-purple-700 rounded-xl font-semibold hover:bg-purple-200 transition">
                Ver grupos →
              </button>
              <button onClick={generateGroups} disabled={loading} className="px-4 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition disabled:opacity-50">
                {loading ? "..." : "🔄 Regenerar"}
              </button>
            </div>
          )}
        </div>
      )}

      {/* GROUPS SECTION */}
      {activeSection === "groups" && (
        <div className="space-y-4">
          {!groups ? (
            <div className="space-y-4">
              <p className="text-sm text-gray-500 text-center">Aún no se han generado grupos.</p>
              <button onClick={generateGroups} disabled={loading} className="w-full py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition disabled:opacity-50">
                {loading ? "Generando grupos con IA..." : "✨ Generar grupos complementarios"}
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-white rounded-xl shadow-sm p-4 border border-gray-100">
                <h2 className="font-bold text-lg text-gray-800 mb-1">🧩 Grupos sugeridos</h2>
                <p className="text-sm text-gray-500 mb-4">{groups.rationale}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {groups.groups.map((group, i) => (
                    <div key={i} className="border border-gray-200 rounded-lg p-3">
                      <p className="text-xs font-bold text-gray-500 mb-1">GRUPO {i + 1}</p>
                      {groups.groupNotes?.[i] && (
                        <p className="text-xs text-blue-600 italic mb-2">{groups.groupNotes[i]}</p>
                      )}
                      <div className="space-y-1">
                        {group.map((member) => (
                          <div key={member} className="flex items-center justify-between">
                            <span className="text-sm text-gray-800">{member}</span>
                            <span className={`text-xs px-2 py-0.5 rounded-full ${PROFILE_COLORS[dominantProfile(member)] || "bg-gray-100 text-gray-600"}`}>
                              {dominantProfile(member)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <button onClick={generateGroups} disabled={loading} className="w-full py-2 bg-purple-100 text-purple-700 rounded-xl font-semibold hover:bg-purple-200 transition disabled:opacity-50 text-sm">
                {loading ? "Regenerando..." : "🔄 Regenerar grupos"}
              </button>
            </div>
          )}
        </div>
      )}

      {/* SIMULATOR SECTION */}
      {activeSection === "simulator" && (
        <div className="space-y-4">
          <div className="bg-indigo-50 rounded-xl p-4 border border-indigo-100">
            <h2 className="font-bold text-lg text-gray-800 mb-1">🔬 Simulador de dinámica grupal</h2>
            <p className="text-sm text-gray-500">Simula conflictos, roles y rendimiento esperado para cada grupo.</p>
          </div>
          {!groups ? (
            <div className="space-y-3">
              <p className="text-sm text-gray-500 text-center">Primero genera los grupos para poder simular.</p>
              <button onClick={() => { generateGroups(); }} disabled={loading} className="w-full py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition disabled:opacity-50">
                {loading ? "Generando..." : "✨ Generar grupos primero"}
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {groups.groups.map((group, i) => (
                <GroupSimulator key={i} group={group} groupIndex={i} profiles={dominantProfiles} />
              ))}
            </div>
          )}
        </div>
      )}

      {/* CSV Download */}
      <button
        onClick={() => {
          const headers = ["Alumno", ...questions.map((q) => `${q.profile}: ${q.text}`)];
          const rows = students.map((s) => {
            const ans = allAnswers[s] || {};
            return [s, ...questions.map((q) => (ans[q.id] || []).join(" | "))];
          });
          const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
          const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "sociograma_respuestas.csv";
          a.click();
          URL.revokeObjectURL(url);
        }}
        className="w-full py-3 bg-green-600 text-white rounded-xl font-semibold hover:bg-green-700 transition"
      >
        ⬇️ Descargar respuestas CSV
      </button>

      <button onClick={onReset} className="w-full py-3 bg-gray-200 text-gray-700 rounded-xl font-semibold hover:bg-gray-300 transition">
        Nueva encuesta
      </button>
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────
type Screen = "setup" | "generating" | "survey" | "results";

export default function App() {
  const [screen, setScreen] = useState<Screen>("setup");
  const [students, setStudents] = useState<string[]>([]);
  const [groupSize, setGroupSize] = useState(5);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [allAnswers, setAllAnswers] = useState<Record<string, Answers>>({});

  const handleStart = async (s: string[], gs: number) => {
    setStudents(s);
    setGroupSize(gs);
    setScreen("generating");
    const res = await complete([
      {
        role: "user",
        content: [
          {
            text: `Eres un psicólogo educativo. Genera 10 preguntas de sociograma para una clase de ${s.length} alumnos. El objetivo es detectar perfiles complementarios para formar grupos equilibrados: Líder, Creativo, Mediador, Trabajador, Apoyo, Organizador.\n\nCada pregunta debe:\n- Ser concreta y fácil de responder\n- Apuntar a detectar un perfil específico\n- Estar redactada en segunda persona ("¿A quién...?")\n\nResponde SOLO con JSON válido:\n{\n  "questions": [\n    {"id": "q1", "text": "¿A quién...?", "profile": "Líder"},\n    ...\n  ]\n}`,
          },
        ],
      },
    ]);
    let qs = DEFAULT_QUESTIONS;
    try {
      const match = res.response.match(/\{[\s\S]*\}/);
      const parsed = match ? JSON.parse(match[0]) : null;
      if (Array.isArray(parsed?.questions) && parsed.questions.length > 0) qs = parsed.questions;
    } catch { /* usa las preguntas por defecto */ }
    setQuestions(qs);
    setCurrentIndex(0);
    setAllAnswers({});
    setScreen("survey");
  };

  const handleSubmit = (answers: Answers) => {
    const student = students[currentIndex];
    const updated = { ...allAnswers, [student]: answers };
    setAllAnswers(updated);
    if (currentIndex + 1 < students.length) {
      setCurrentIndex(currentIndex + 1);
      window.scrollTo(0, 0);
    } else {
      setScreen("results");
    }
  };

  const handleReset = () => {
    setScreen("setup");
    setStudents([]);
    setCurrentIndex(0);
    setAllAnswers({});
    setQuestions([]);
  };

  return (
    <div className="py-6 px-4 min-h-screen bg-gray-50">
      <div className="max-w-lg mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Sociograma de clase</h1>
          <p className="text-gray-500 text-sm mt-1">Detección de perfiles y grupos complementarios</p>
        </div>

        {screen === "setup" && <Setup onStart={handleStart} />}

        {screen === "generating" && (
          <div className="flex flex-col items-center justify-center py-20 gap-4">
            <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-gray-600 font-medium">Generando preguntas con IA...</p>
          </div>
        )}

        {screen === "survey" && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-gray-500">Alumno {currentIndex + 1} de {students.length}</p>
                <p className="font-bold text-gray-800 text-lg">{students[currentIndex]}</p>
              </div>
              <div className="text-right">
                <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full transition-all" style={{ width: `${(currentIndex / students.length) * 100}%` }} />
                </div>
                <p className="text-xs text-gray-400 mt-1">{Math.round((currentIndex / students.length) * 100)}% completado</p>
              </div>
            </div>
            <StudentForm key={currentIndex} students={students} currentStudent={students[currentIndex]} questions={questions} onSubmit={handleSubmit} />
          </div>
        )}

        {screen === "results" && (
          <Results students={students} allAnswers={allAnswers} questions={questions} groupSize={groupSize} onReset={handleReset} />
        )}
      </div>
    </div>
  );
}

