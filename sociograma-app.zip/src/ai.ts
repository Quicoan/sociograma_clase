// Capa de IA. Sin clave de API la app funciona igualmente con algoritmos locales.
const KEY = "sociograma_api_key";
export const getApiKey = () => { try { return localStorage.getItem(KEY) || ""; } catch { return ""; } };
export const setApiKey = (v: string) => { try { v ? localStorage.setItem(KEY, v) : localStorage.removeItem(KEY); } catch { /* ignore */ } };

type Msg = { role: string; content: { text: string }[] };

/** Llama a Claude desde el navegador. Nunca lanza: devuelve "" si no hay clave o falla (la app usa su fallback). */
export async function complete(messages: Msg[]): Promise<{ response: string }> {
  const key = getApiKey();
  if (!key) return { response: "" };
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 30000);
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "content-type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true",
      },
      body: JSON.stringify({
        model: "claude-sonnet-5-5",
        max_tokens: 4000,
        messages: messages.map((m) => ({ role: m.role, content: m.content.map((c) => c.text).join("\n") })),
      }),
    });
    if (!r.ok) return { response: "" };
    const d = await r.json();
    return { response: (d.content || []).map((c: { text?: string }) => c.text || "").join("") };
  } catch {
    return { response: "" };
  } finally {
    clearTimeout(timer);
  }
}

export const DEFAULT_QUESTIONS = [
  { id: "q1", text: "¿A quién elegirías para liderar un proyecto de clase?", profile: "Líder" },
  { id: "q2", text: "¿Quién crees que tiene las mejores ideas originales?", profile: "Creativo" },
  { id: "q3", text: "¿A quién acudirías si hay un conflicto en el grupo?", profile: "Mediador" },
  { id: "q4", text: "¿Quién crees que trabaja más duro y de forma más constante?", profile: "Trabajador" },
  { id: "q5", text: "¿A quién acudirías si necesitas apoyo emocional?", profile: "Apoyo" },
  { id: "q6", text: "¿Quién organiza mejor las tareas y los tiempos?", profile: "Organizador" },
  { id: "q7", text: "¿Con quién te gustaría trabajar en un proyecto importante?", profile: "Trabajador" },
  { id: "q8", text: "¿Quién propone soluciones cuando el grupo está bloqueado?", profile: "Líder" },
  { id: "q9", text: "¿Quién hace que el ambiente del grupo sea más agradable?", profile: "Mediador" },
  { id: "q10", text: "¿Quién aportaría ideas más innovadoras a un proyecto creativo?", profile: "Creativo" },
];

const shuffle = <T,>(a: T[]) => { const b = [...a]; for (let i = b.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [b[i], b[j]] = [b[j], b[i]]; } return b; };

/** Grupos locales: reparte por perfil en serpentina para mezclar perfiles y limitar líderes. Cada llamada da una alternativa. */
export function localGroups(students: string[], profiles: Record<string, string>, groupSize: number) {
  const n = Math.max(1, Math.ceil(students.length / groupSize));
  const buckets: Record<string, string[]> = {};
  shuffle(students).forEach((s) => (buckets[profiles[s] || "Sin perfil"] ||= []).push(s));
  const ordered = Object.entries(buckets).sort((a, b) => b[1].length - a[1].length).flatMap(([, v]) => v);
  const groups: string[][] = Array.from({ length: n }, () => []);
  ordered.forEach((s, i) => { const r = Math.floor(i / n); const k = i % n; groups[r % 2 ? n - 1 - k : k].push(s); });
  return {
    groups: groups.filter((g) => g.length),
    rationale: "Grupos generados localmente (sin IA): se reparten los perfiles de forma equilibrada para que cada grupo mezcle estilos y los líderes queden distribuidos. Añade una clave de API en la pantalla inicial para análisis con IA que además tenga en cuenta elecciones mutuas.",
    groupNotes: groups.filter((g) => g.length).map((g) => `Perfiles: ${[...new Set(g.map((m) => profiles[m] || "Sin perfil"))].join(", ")}`),
  };
}

const ROLE: Record<string, string> = { Líder: "Coordinador", Creativo: "Generador de ideas", Mediador: "Moderador", Trabajador: "Ejecutor principal", Apoyo: "Cuidador del clima", Organizador: "Gestor de tiempos" };
const TASKS: Record<string, string[]> = {
  "Presentación oral": ["Líder", "Mediador"], "Proyecto creativo": ["Creativo", "Apoyo"], "Investigación": ["Trabajador", "Organizador"],
  "Debate": ["Líder", "Creativo"], "Tarea técnica": ["Organizador", "Trabajador"],
};

/** Simulación local basada en reglas simples sobre los perfiles. */
export function localSim(group: string[], profiles: Record<string, string>) {
  const ps = group.map((m) => profiles[m] || "Sin perfil");
  const count = (p: string) => ps.filter((x) => x === p).length;
  const conflicts: { issue: string; severity: "alta" | "media" | "baja"; suggestion: string }[] = [];
  if (count("Líder") >= 2) conflicts.push({ issue: "Varios líderes pueden competir por la dirección.", severity: "alta", suggestion: "Reparte áreas de liderazgo distintas a cada uno." });
  if (!count("Mediador")) conflicts.push({ issue: "No hay mediador claro para resolver desacuerdos.", severity: "media", suggestion: "Pide al docente que supervise las primeras decisiones." });
  if (!count("Organizador")) conflicts.push({ issue: "Riesgo de falta de planificación.", severity: "media", suggestion: "Usa un calendario de tareas compartido." });
  if (!conflicts.length) conflicts.push({ issue: "Sin tensiones evidentes; puede haber exceso de consenso.", severity: "baja", suggestion: "Fomenta que se expresen opiniones distintas." });
  return {
    conflicts,
    roles: group.map((m, i) => ({ member: m, role: ROLE[ps[i]] || "Colaborador", reason: `Encaja con su perfil ${ps[i]}.` })),
    performance: Object.entries(TASKS).map(([task, f]) => {
      const score = Math.min(10, 4 + f.reduce((s, p) => s + Math.min(count(p), 2) * 1.5, 0));
      return { task, score: Math.round(score), notes: "Estimación local según los perfiles presentes." };
    }),
    overall: `Simulación local (sin IA) para un grupo de ${group.length} personas. Añade una clave de API para un análisis más detallado.`,
  };
}
