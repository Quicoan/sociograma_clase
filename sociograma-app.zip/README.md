# Sociograma de clase

Herramienta web para que docentes detecten perfiles de alumnos (Líder, Creativo, Mediador, Trabajador, Apoyo, Organizador) y formen grupos equilibrados. Especificación en `docs/`.

## Uso local
```bash
npm install
npm run dev
```

## Publicar en GitHub Pages
1. Sube el repo a GitHub (rama `main`).
2. En *Settings → Pages → Source* elige **GitHub Actions**.
3. Cada push a `main` despliega la app automáticamente.

## IA (opcional)
Sin configuración la app funciona con preguntas por defecto y algoritmos locales.
Si introduces una clave de API de Anthropic en la pantalla inicial, se usa Claude para preguntas, grupos y simulación.
La clave se guarda solo en el `localStorage` de tu navegador; no la incluyas en el código. Úsala solo en tu propio equipo: para compartir la app con otros usuarios sería necesario un pequeño servidor intermedio.
