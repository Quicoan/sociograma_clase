import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

// base "./" permite desplegar en GitHub Pages sea cual sea el nombre del repo
export default defineConfig({ base: "./", plugins: [react(), tailwindcss()] });
