# Steering: Sociograma de clase

## Objetivo
Convertir un prototipo de encuesta de sociograma con IA en una aplicación web funcional que permita a educadores detectar perfiles de estudiantes y formar grupos equilibrados.

## Contexto
Este prototipo fue desarrollado en PartyRock. El código en `src/` es una referencia para entender la intención del producto, NO para copiar directamente. PartyRock tiene limitaciones de sandbox (sin localStorage, sin formularios reales, runtime JS compartido). Tu implementación debe usar arquitectura de producción.

## Instrucciones

1. Lee `Requirements.md` para la especificación completa del producto.
2. Examina el código en `src/` para entender:
   - Flujo de usuario: setup → generating → survey → results
   - Estado: estudiantes, respuestas, preguntas, grupos
   - Cómo se calculan perfiles y se generan grupos con IA
3. El código prototipo es un punto de partida, no la solución final.

## Guía

- **Sin presupuesto técnico**: El usuario probablemente no tiene background técnico. Explica en lenguaje natural.
- **Sin stack definido**: Antes de construir, recomienda opciones (React + TypeScript + Tailwind es sólido y está probado aquí; Next.js si necesita servidor; Svelte si prefiere algo más ligero).
- **Preguntas abiertas**: No conocemos escala (¿cuántas clases simultáneas?), deployment (¿cloud?¿local?), o requisitos de usuario (¿educador solista?¿institución?).
- **Velocidad primero**: Entrega un MVP funcional rápidamente. Pulir arquitectura después.
- **Cuando dudes**: Elige lo más simple. Explica la opción y por qué.