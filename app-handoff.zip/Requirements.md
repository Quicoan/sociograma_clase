# Requisitos: Sociograma de clase

## Descripción general
Una aplicación que utiliza IA para analizar las dinámicas de grupo en una clase mediante un sociograma interactivo. Permite a educadores recopilar respuestas de estudiantes, detectar perfiles complementarios y generar sugerencias de agrupamiento basadas en psicología educativa.

## Requisitos funcionales

### Configuración inicial

| ID | Requisito |
|----|-----------|
| REQ-001 | WHEN el usuario abre la aplicación THE SYSTEM SHALL mostrar una pantalla de configuración con opciones para definir el número de alumnos, prefijo de nombres y tamaño de grupo |
| REQ-002 | WHEN el usuario activa la opción "Introducir nombres reales" THE SYSTEM SHALL mostrar un área de texto para que ingrese nombres personalizados, uno por línea |
| REQ-003 | WHEN el usuario ingresa nombres personalizados THE SYSTEM SHALL validar que al menos un nombre sea válido antes de permitir continuar |
| REQ-004 | WHEN el usuario hace clic en "Generar preguntas con IA" THE SYSTEM SHALL generar 10 preguntas de sociograma adaptadas al número de alumnos configurado |

### Generación de preguntas

| ID | Requisito |
|----|-----------|
| REQ-005 | WHEN el sistema genera preguntas THE SYSTEM SHALL crear 10 preguntas que detecten seis perfiles: Líder, Creativo, Mediador, Trabajador, Apoyo, Organizador |
| REQ-006 | WHEN se generan preguntas THE SYSTEM SHALL asignar a cada pregunta un perfil específico y redactarla en formato "¿A quién...?" |
| REQ-007 | WHEN las preguntas se generan exitosamente THE SYSTEM SHALL mostrar un estado de carga mientras contacta la API de IA |
| REQ-008 | WHEN falla la generación de preguntas THE SYSTEM SHALL mostrar un conjunto predeterminado de 10 preguntas de ejemplo |

### Encuesta de estudiantes

| ID | Requisito |
|----|-----------|
| REQ-009 | WHEN un estudiante comienza la encuesta THE SYSTEM SHALL mostrar una pregunta a la vez con una lista de botones de selección de compañeros |
| REQ-010 | WHEN un estudiante selecciona compañeros THE SYSTEM SHALL permitir un máximo de 3 selecciones por pregunta |
| REQ-011 | WHEN un estudiante intenta seleccionar más de 3 compañeros THE SYSTEM SHALL desactivar nuevas selecciones hasta que deseleccione alguno |
| REQ-012 | WHEN un estudiante completa una pregunta THE SYSTEM SHALL permitir dejar la pregunta en blanco y pasar a la siguiente |
| REQ-013 | WHEN un estudiante envía sus respuestas THE SYSTEM SHALL guardar las respuestas y mostrar el siguiente estudiante si existen más |
| REQ-014 | WHEN es el último estudiante en la lista THE SYSTEM SHALL guardar sus respuestas y navegar a la pantalla de resultados |
| REQ-015 | WHEN se muestra un estudiante THE SYSTEM SHALL exhibir su nombre, número de progreso (X de N) y una barra de progreso visual |
| REQ-016 | WHEN se muestra una pregunta THE SYSTEM SHALL incluir una etiqueta con el perfil que detecta (ej. "Líder", "Creativo") |

### Panel de perfiles

| ID | Requisito |
|----|-----------|
| REQ-017 | WHEN se carguen los resultados THE SYSTEM SHALL calcular un perfil dominante para cada estudiante basado en las selecciones recibidas |
| REQ-018 | WHEN se muestren perfiles THE SYSTEM SHALL exhibir un gráfico de barras con la distribución de perfiles en toda la clase |
| REQ-019 | WHEN se selecciona un estudiante en la lista THE SYSTEM SHALL mostrar un gráfico de radar con sus puntuaciones en cada perfil |
| REQ-020 | WHEN se muestra el radar de un estudiante THE SYSTEM SHALL mostrar también números con las puntuaciones brutas de cada perfil |

### Generación de grupos

| ID | Requisito |
|----|-----------|
| REQ-021 | WHEN el usuario hace clic en "Generar grupos complementarios" THE SYSTEM SHALL analizar todas las respuestas y crear grupos equilibrados basados en IA |
| REQ-022 | WHEN se generan grupos THE SYSTEM SHALL respetar las siguientes reglas: incluir elecciones mutuas, mezclar perfiles, evitar rechazos, distribuir alumnos aislados, máximo 1-2 líderes por grupo |
| REQ-023 | WHEN se generan grupos THE SYSTEM SHALL mostrar una explicación de la lógica utilizada |
| REQ-024 | WHEN se generan grupos THE SYSTEM SHALL permitir al usuario regenerar grupos para obtener alternativas |
| REQ-025 | WHEN se muestren grupos THE SYSTEM SHALL mostrar cada grupo con sus miembros y el perfil dominante de cada uno |
| REQ-026 | WHEN se muestren grupos THE SYSTEM SHALL incluir notas específicas de recomendación para cada grupo si las IA las proporciona |

### Simulador de dinámica grupal

| ID | Requisito |
|----|-----------|
| REQ-027 | WHEN el usuario hace clic en "Simular" para un grupo THE SYSTEM SHALL analizar conflictos potenciales, roles recomendados y rendimiento esperado |
| REQ-028 | WHEN se simula un grupo THE SYSTEM SHALL mostrar 2-3 conflictos potenciales con severidad (alta/media/baja) y sugerencias de mitigación |
| REQ-029 | WHEN se simula un grupo THE SYSTEM SHALL asignar un rol concreto a cada miembro con justificación breve |
| REQ-030 | WHEN se simula un grupo THE SYSTEM SHALL puntuar el rendimiento esperado (1-10) en cinco tipos de tarea: Presentación oral, Proyecto creativo, Investigación, Debate, Tarea técnica |
| REQ-031 | WHEN se simula un grupo THE SYSTEM SHALL mostrar una valoración general en 2 frases |
| REQ-032 | WHEN se muestren resultados de simulación THE SYSTEM SHALL permitir cambiar entre tres pestañas: Conflictos, Roles, Rendimiento |
| REQ-033 | WHEN se muestra el simulador THE SYSTEM SHALL permitir al usuario regenerar la simulación para obtener análisis alternativos |
| REQ-034 | WHEN se carga una simulación THE SYSTEM SHALL mostrar un indicador de carga |

### Exportación de datos

| ID | Requisito |
|----|-----------|
| REQ-035 | WHEN el usuario hace clic en "Descargar respuestas CSV" THE SYSTEM SHALL generar un archivo CSV con todas las respuestas de todos los estudiantes |
| REQ-036 | WHEN se genera el CSV THE SYSTEM SHALL incluir columnas para cada estudiante y cada pregunta con las respuestas |
| REQ-037 | WHEN se descarga el archivo THE SYSTEM SHALL nombrar el archivo "sociograma_respuestas.csv" |

### Flujo general

| ID | Requisito |
|----|-----------|
| REQ-038 | WHEN el usuario hace clic en "Nueva encuesta" THE SYSTEM SHALL reiniciar la aplicación a la pantalla de configuración inicial |
| REQ-039 | WHEN se cambia de pantalla THE SYSTEM SHALL mostrar claramente dónde está el usuario en el flujo (setup → generating → survey → results) |

## Requisitos no funcionales

| ID | Requisito |
|----|-----------|
| NFR-001 | THE SYSTEM SHALL responder a acciones del usuario en menos de 1 segundo para interacciones locales |
| NFR-002 | THE SYSTEM SHALL ser responsivo y adaptarse correctamente a pantallas desde 320px hasta 2560px de ancho |
| NFR-003 | THE SYSTEM SHALL mostrar un indicador de carga clara cuando se comunica con la API de IA (máximo 30 segundos de espera) |
| NFR-004 | THE SYSTEM SHALL mantener un diseño limpio con máximo tres niveles de navegación |
| NFR-005 | THE SYSTEM SHALL utilizar contraste de color suficiente para cumplir con WCAG AA |
| NFR-006 | THE SYSTEM SHALL mostrar estados vacíos informativos cuando no hay datos (ej. "Aún no se han generado grupos") |
| NFR-007 | THE SYSTEM SHALL mostrar mensajes de error claros si la API de IA no responde o falla |
| NFR-008 | THE SYSTEM SHALL permitir que el usuario continúe con datos parciales (respuestas incompletas permitidas) |

## Notas de diseño

### Disposición y navegación
- **Estructura de pantalla única**: La aplicación funciona como un flujo de una pantalla con cuatro estados visibles: Setup, Generating, Survey, Results
- **Navegación con pestañas**: En la pantalla de resultados, tres pestañas permiten cambiar entre "Perfiles", "Grupos" y "Simulador"
- **Máximo ancho**: El contenido se centra con un máximo de 512px para mantener legibilidad en pantallas grandes
- **Relleno responsivo**: El contenido tiene relleno adaptado para móvil (px-4) que puede aumentar en escritorio

### Paleta de colores
- **Azul primario (#3b82f6 / #2563eb)**: Botones de acción principal, barras de progreso
- **Púrpura (#a855f7 / #9333ea)**: Botones secundarios, simulador
- **Gris de fondo**: #f9fafb para toda la página, #ffffff para tarjetas
- **Perfiles con colores semánticos**:
  - Líder: púrpura (#a855f7)
  - Creativo: amarillo (#eab308)
  - Mediador: verde (#22c55e)
  - Trabajador: azul (#3b82f6)
  - Apoyo: rosa (#ec4899)
  - Organizador: naranja (#f97316)
- **Severidad de conflictos**:
  - Alta: rojo (#ef4444)
  - Media: amarillo (#eab308)
  - Baja: verde (#22c55e)

### Componentes de interfaz
- **Tarjetas**: Bordes gris claro (border-gray-100), sombra sutil (shadow-sm), esquinas redondeadas (rounded-xl), relleno 16px (p-4)
- **Botones**: Bordes redondeados (rounded-lg o rounded-xl), transiciones suaves, estados de deshabilitado con opacidad
- **Controles deslizantes**: Rango (range input) con estilos nativos del navegador
- **Gráficos**:
  - Gráfico de barras: Barras horizontales con colores semánticos, etiquetas a la izquierda
  - Gráfico de radar: SVG con polígono relleno semitransparente, ejes y etiquetas de perfil

### Estados especiales
- **Carga**: Spinner animado circular con borde de color primario + texto descriptivo
- **Vacío**: Texto gris claro indicando "Aún no se han generado grupos" u similar
- **Error**: Recuperación silenciosa con valores por defecto (ej. 10 preguntas predeterminadas)
- **Selección**: Fondos de color con transiciones suaves, cambio de cursor a pointer

### Interacción
- **Selección múltiple limitada**: Máximo 3 selecciones; botones deshabilitados después de llegar al límite
- **Mostrar/ocultar**: Simulador con botones de expandir/contraer ("▼ Ver" vs "▲ Cerrar")
- **Pestañas**: Cambio instantáneo entre secciones sin recarga
- **Descarga**: Generación de blob CSV descargado automáticamente al navegador
- **Regeneración**: Botón "🔄 Regenerar" que reinicia el análisis de IA